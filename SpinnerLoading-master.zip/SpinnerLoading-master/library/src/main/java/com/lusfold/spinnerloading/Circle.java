package com.lusfold.spinnerloading;

/**
 * @author <a href="http://www.lusfold.com" target="_blank">Lusfold</a>
 */
public class Circle {
    public float[] center;
    public float radius;
}
